import React from 'react';
import { Routes, Route } from 'react-router-dom';
import H1 from './components/Home';
import R1 from './components/Register';
import D1 from './components/Delete';
import Login from './components/Login';
import Appbar from './components/Appbar1';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={"image1.jpg"} className="App-logo" alt="logo" />
        &nbsp; &nbsp;
        <h2>
          PSK Fashion Designing System
        </h2>
      </header>
      <div className="App-Body">
        <Appbar />
        <Routes>
          <Route path='/' element={<H1 />} />
          <Route path='/reg' element={<R1 />} />
          <Route path='/bac' element={<H1 />} />
          <Route path='/del' element={<D1 />} />
          <Route path='/log' element={<Login />} /> 
        </Routes>
      </div>
    </div>
  );
}

export default App;
