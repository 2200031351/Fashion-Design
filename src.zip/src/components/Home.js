import { Typography } from '@mui/material'
import Button from '@mui/material/Button';
import { blue } from '@mui/material/colors';
import React from 'react'

const Home = () => {
  return (
    <div>
      <Typography mt={5} variant='h4' textAlign={'center'}>
      OUR PHILOSOPHY
      </Typography>
      <Typography mt={5} variant='h4' textAlign={'center'}>
      Fast, efficient, and reliable, we are a reputable and well-known Water Testing Service in San Francisco. Our team goes above and beyond to cater to each project’s specific needs. We want our customers to be satisfied with our work, which is why we provide open communication channels throughout every step of the way. Browse our site to learn more about the services and plans we offer.
      </Typography>
      <Typography mt={10} variant='h4'>
      <img src={"image.jpg"} className="App-img" alt="logo" />
      Cape dresses can be made in any style, any length, any fabric. The only thing a cape dress must have is, of course, a cape. This is a very classic look that has been seen on celebrities and royals through the last few decades, with many famous faces stepping out in daring cape dress styles. When you want to make a stunning im[pression at a formal event and you’re feeling super fashionable, a cape dress is the perfect choice.
        &nbsp; &nbsp;</Typography>
        <Typography mt={10} variant='h4'textAlign={'right'}>
       <img src={"image2.jpg"} className="App-img" alt="logo"/>

       Traditionally, ball gowns are sleeveless gowns with tight bodices and full, wide skirts. Ball gowns are often very elaborate and worn for the most formal events. The ball gown silhouette is a popular wedding dress style. Because of the silhouette’s association with Disney characters, the ball gown is also known as the princess dress. 
        &nbsp; &nbsp;</Typography>
        <Typography mt={10} variant='h4'>
        <img src={"image3.jpg"} className="App-img" alt="logo"/>
        The coat dress or coatdress dates to around 1914. The bottom of the dress has a standard skirt in any length but the bodice of the dress resembles a single or double-breasted coat, according to “The Dictionary of Fashion History.” This style often features lapels. The coat dress is similar to the blazer dress. 
        &nbsp; &nbsp; 
        </Typography>
        <Button
            href="https://tailornova.com/designer"
            style={{ textDecoration: 'none', color: 'blue', fontSize: 'xx-large' }}
            variant="text"
          >
            ADD YOUR DESIGN
          </Button>
        
    </div>
  )
}

export default Home