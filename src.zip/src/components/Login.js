import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';

function Login() {
  // State for storing input values
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [maskedPassword, setMaskedPassword] = useState('');

  // Function to handle form submission
  const handleSubmit = (event) => {
    event.preventDefault();
    console.log('Username:', username);
    console.log('Password:', password); // Log the actual password
    // Add your authentication logic here
  };

  // Function to mask the password
  const handleMaskPassword = (event) => {
    const value = event.target.value;
    setMaskedPassword(value.replace(/./g, '*')); // Replace each character with '*'
    setPassword(value); // Update the actual password state
  };

  return (
    <Container component="main" maxWidth="xs">
      <Typography component="h1" variant="h5">
        Login
      </Typography>
      <form onSubmit={handleSubmit}>
        <TextField
          variant="outlined"
          margin="normal"
          required
          fullWidth
          id="username"
          label="Username"
          name="username"
          autoComplete="username"
          autoFocus
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
        <TextField
          variant="outlined"
          margin="normal"
          required
          fullWidth
          name="password"
          label="Password"
          type="password"
          id="password"
          autoComplete="current-password"
          value={maskedPassword} // Display masked password instead of actual password
          onChange={handleMaskPassword} // Call handleMaskPassword instead of directly updating password state
        />
        <Button
          type="submit"
          fullWidth
          variant="contained"
          color="primary"
          style={{ margin: '20px 0' }}
        >
          Sign In
        </Button>
        <Typography>
          <Link to="/reg" variant="body2">
            Don't have an account? Register
          </Link>
        </Typography>
      </form>
    </Container>
  );
}

export default Login;
